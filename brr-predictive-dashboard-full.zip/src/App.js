import React, { useEffect, useMemo, useState } from "react";

/**
 * BRR Predictive Dashboard – Clickable Prototype
 * ------------------------------------------------
 * (Full code included, ready to run in React project)
 */

const DOMAINS = ["Phonology", "Morphology", "Syntax", "Semantics", "Pragmatics"];
const ONTOLOGY = ["Object", "Action", "Property", "State", "Event", "Relationship"];

const clamp = (n, min = 0, max = 100) => Math.max(min, Math.min(max, n));
const pct = (n) => `${clamp(n)}%`;

function classNames(...a) {
  return a.filter(Boolean).join(" ");
}

function badgeColor(level) {
  return level === "High"
    ? "bg-red-100 text-red-800 border-red-300"
    : level === "Moderate"
    ? "bg-amber-100 text-amber-900 border-amber-300"
    : "bg-emerald-100 text-emerald-900 border-emerald-300";
}

function computeRisk(s) {
  const attendancePenalty = 100 - clamp(s.attendance);
  const assignmentsPenalty = 100 - clamp(s.assignmentsCompleted);
  const lowComprehension = 100 - clamp(s.comprehension);
  const domainDeficits = DOMAINS.map((d) => s.domains[d]).filter((v) => v < 80);
  const domainPenalty = domainDeficits.length
    ? domainDeficits.reduce((a, b) => a + (80 - b), 0) / domainDeficits.length
    : 0;
  const ontoVals = ONTOLOGY.map((o) => s.ontology[o]);
  const ontoWeak = ontoVals.filter((v) => v < 70);
  const ontoPenalty = ontoWeak.length * 5;
  const targetWcpm = s.grade <= 2 ? 70 : s.grade === 3 ? 100 : s.grade === 4 ? 115 : 130;
  const fluencyPenalty = Math.max(0, targetWcpm - s.wcpm) * 0.4;
  const engagementPenalty = Math.max(0, 30 - s.timeOnTask) * 0.8;
  const raw =
    0.22 * attendancePenalty +
    0.18 * assignmentsPenalty +
    0.22 * lowComprehension +
    0.16 * domainPenalty +
    0.10 * fluencyPenalty +
    0.07 * engagementPenalty +
    0.05 * ontoPenalty;
  const score = Math.round(clamp(raw, 0, 100));
  const level = score >= 65 ? "High" : score >= 40 ? "Moderate" : "Low";
  const focus = [];
  if (domainPenalty > 0) {
    const weakest = [...DOMAINS].sort((a, b) => s.domains[a] - s.domains[b])[0];
    focus.push(`Domain: ${weakest}`);
  }
  if (ontoWeak.length) {
    const weakestOntos = ONTOLOGY.filter((o) => s.ontology[o] < 70).slice(0, 2);
    focus.push(`Ontology: ${weakestOntos.join(", ")}`);
  }
  if (s.comprehension < 75) focus.push("Comprehension: Cause/Effect or Inference");
  if (s.assignmentsCompleted < 85) focus.push("Work completion habits");
  if (s.attendance < 92) focus.push("Attendance consistency");
  return { score, level, focus };
}

function recommendActions(s) {
  const { level, focus } = computeRisk(s);
  const actions = [];
  actions.push(
    "Assessment: Quick 5-item check on comprehension subskills (MI, Inference, C/E, Vocab, Syntax)"
  );
  const ontoGaps = ONTOLOGY.filter((o) => s.ontology[o] < 70);
  if (ontoGaps.length) {
    actions.push(`Ontology: Run STQ prompts on ${ontoGaps.join(", ")} using today's read-aloud.`);
  } else {
    actions.push("Ontology: Spiral review across all six categories via orbit mapping.");
  }
  const weakestDomain = [...DOMAINS].sort((a, b) => s.domains[a] - s.domains[b])[0];
  actions.push(`Domains: Mini-lesson targeting ${weakestDomain} (10–12 min).`);
  actions.push("Content: Choose a real book at target Lexile ±75 with clear event chains.");
  actions.push(
    "Skill: Sentence combining for syntax; vocabulary-in-context for semantics; affix hunt for morphology."
  );
  actions.push(
    "Task: Passcode Reasoning sheet → slot details into UCB bins (Systems/Processes, Cause/Motivation, Change/Development, Evidence/Reasoning) then write a one-sentence principle."
  );
  if (level === "High") actions.unshift("🚨 Priority: Daily 15-min intervention + caregiver script.");
  if (level === "Moderate") actions.unshift("⚠️ Schedule 3x/week small-group and caregiver nudge.");
  return { actions, focus, level };
}

const startStudents = [
  {
    id: "S001",
    name: "Aiden",
    grade: 3,
    language: "English",
    attendance: 95,
    assignmentsCompleted: 92,
    timeOnTask: 35,
    booksRead: 12,
    genre: "Adventure",
    lexile: 620,
    wcpm: 105,
    comprehension: 76,
    benchmark: 72,
    domains: { Phonology: 88, Morphology: 82, Syntax: 75, Semantics: 80, Pragmatics: 78 },
    ontology: { Object: 84, Action: 78, Property: 76, State: 68, Event: 71, Relationship: 66 },
    notes: "Misses cause/effect; needs morphology spiral."
  },
  {
    id: "S002",
    name: "Brianna",
    grade: 3,
    language: "Spanish–English",
    attendance: 89,
    assignmentsCompleted: 75,
    timeOnTask: 20,
    booksRead: 7,
    genre: "Fantasy",
    lexile: 540,
    wcpm: 85,
    comprehension: 58,
    benchmark: 55,
    domains: { Phonology: 72, Morphology: 65, Syntax: 70, Semantics: 68, Pragmatics: 60 },
    ontology: { Object: 70, Action: 62, Property: 65, State: 58, Event: 61, Relationship: 57 },
    notes: "Syntax & inference are weak; caregiver script."
  },
  {
    id: "S003",
    name: "Caleb",
    grade: 3,
    language: "English",
    attendance: 98,
    assignmentsCompleted: 99,
    timeOnTask: 45,
    booksRead: 20,
    genre: "Nonfiction",
    lexile: 710,
    wcpm: 120,
    comprehension: 91,
    benchmark: 90,
    domains: { Phonology: 94, Morphology: 90, Syntax: 88, Semantics: 92, Pragmatics: 89 },
    ontology: { Object: 92, Action: 90, Property: 88, State: 85, Event: 91, Relationship: 86 },
    notes: "Occasional vocab misinterpretation."
  }
];

export default function App() {
  const [students] = useState(startStudents);
  const { level, score } = computeRisk(students[0]);
  const recs = recommendActions(students[0]);

  return (
    <div style={{ padding: 20, fontFamily: "system-ui" }}>
      <h1>BRR Predictive Dashboard</h1>
      <h2>Example: {students[0].name}</h2>
      <p>Risk Level: {level} (score {score})</p>
      <h3>Recommended Actions:</h3>
      <ul>
        {recs.actions.map((a, i) => (
          <li key={i}>{a}</li>
        ))}
      </ul>
    </div>
  );
}
